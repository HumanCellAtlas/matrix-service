class UploadCLICommand(object):
    pass
