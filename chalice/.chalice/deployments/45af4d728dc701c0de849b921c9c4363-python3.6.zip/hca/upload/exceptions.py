class UploadException(RuntimeError):
    pass
